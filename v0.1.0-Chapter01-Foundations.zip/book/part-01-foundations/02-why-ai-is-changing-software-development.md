# Chapter 2 – Why AI Is Changing Software Development

## Learning Objectives
- Understand why AI represents a major shift in software engineering.
- Recognize where AI improves developer productivity.
- Identify skills that remain uniquely human.

## Overview
AI is transforming software development by accelerating routine tasks, improving code comprehension, assisting with testing, documentation, debugging, and design discussions. Rather than replacing developers, AI augments their capabilities.

## Where AI Helps
- Requirements analysis
- Architecture discussions
- Code generation
- Refactoring
- Testing
- Documentation
- Code review

## Human Responsibilities
Developers remain responsible for:
- Correctness
- Security
- Privacy
- Compliance
- Final engineering decisions

## Best Practices
- Treat AI as a collaborator.
- Verify outputs.
- Iterate with focused prompts.
- Keep humans in the review loop.

## Mini Lab
Compare implementing a small feature manually versus with AI assistance. Record time saved, quality differences, and review findings.

## Summary
AI changes how software is built by shifting developer effort from routine implementation toward design, validation, and decision-making.
